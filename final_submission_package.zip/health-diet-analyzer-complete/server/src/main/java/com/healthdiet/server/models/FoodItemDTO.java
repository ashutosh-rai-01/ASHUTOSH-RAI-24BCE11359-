package com.healthdiet.server.models;

public class FoodItemDTO {
    public String name;
    public String serving;
    public double calories;
    public double protein_g;
    public double iron_mg;
}
